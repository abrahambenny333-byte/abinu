PRiya Letter Website

Files:
- index.html — the complete website
- assets/funny-reveal.png — the uploaded reveal image

How to use:
1. Keep index.html and the assets folder together.
2. Double-click index.html to preview it in a browser.
3. To put it online, upload both the index.html file and the assets folder to a static website host.

The envelope page has:
- animated chick + cupcake background
- opening envelope animation
- twice-folded interactive paper
- handwritten notebook-style letter
- countdown 3 (blue), 2 (green), 1 (blue)
- your uploaded funny image reveal

The site is responsive for phones and desktops.
